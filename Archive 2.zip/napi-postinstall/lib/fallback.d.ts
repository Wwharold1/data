declare function fallback<T = unknown>(packageJsonPath: string, checkVersion?: boolean): T;
export = fallback;
