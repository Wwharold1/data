import type { Target } from './types.js';
export declare function parseTriple(rawTriple: string): Target;
